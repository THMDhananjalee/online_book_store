import 'package:flutter/material.dart';
import 'category_screen.dart'; // Import the CategoryScreen
import 'store_screen.dart'; // Import the StoreScreen
import 'book_widget.dart'; // Import the BookWidget

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0; // Index for the bottom navigation bar

  // List of screens for the bottom navigation bar
  final List<Widget> _screens = [
    HomeContent(), // Home screen content
    CategoryScreen(), // Category screen
    StoreScreen(), // Store screen
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index; // Update the selected index
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Book Store'),
        bottom: PreferredSize(
          preferredSize: Size.fromHeight(50.0),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Search for books...',
                border: OutlineInputBorder(),
                suffixIcon: Icon(Icons.search),
              ),
            ),
          ),
        ),
      ),
      body: _screens[_selectedIndex], // Display the selected screen
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.category), label: 'Category'),
          BottomNavigationBarItem(icon: Icon(Icons.store), label: 'Store'),
        ],
        currentIndex: _selectedIndex,
        onTap: _onItemTapped, // Handle navigation
      ),
    );
  }
}

class HomeContent extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ListView(
      children: [
        BookWidget(
          title: 'Control Your Mind and Master Your Feelings',
          author: 'Eric Robertson',
          price: '\$18',
          imageUrl: 'assets/book1.jpg',
        ),
        BookWidget(
          title: 'Fourth Wing',
          author: 'Rebecca Yarros',
          price: '\$15',
          imageUrl: 'assets/book2.jpg',
        ),
        BookWidget(
          title: 'The Covenant of Water',
          author: 'Abraham Verghese',
          price: '\$20',
          imageUrl: 'assets/book3.jpg',
        ),
        BookWidget(
          title: 'Iron Flame',
          author: 'Rebecca Yarros',
          price: '\$16',
          imageUrl: 'assets/book4.jpg',
        ),
      ],
    );
  }
}