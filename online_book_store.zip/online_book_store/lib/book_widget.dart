import 'package:flutter/material.dart';

class BookWidget extends StatelessWidget {
  final String title;
  final String author;
  final String price;
  final String imageUrl;

  const BookWidget({
    required this.title,
    required this.author,
    required this.price,
    required this.imageUrl,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        // Navigate to a new screen or show a dialog with the book image
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => BookDetailScreen(imageUrl: imageUrl),
          ),
        );
      },
      child: Card(
        margin: EdgeInsets.all(10),
        child: Padding(
          padding: EdgeInsets.all(10),
          child: Row(
            children: [
              Hero(
                tag: imageUrl, // Unique tag for Hero animation
                child: Image.asset(
                  imageUrl,
                  width: 50,
                  height: 75,
                  fit: BoxFit.cover,
                ),
              ),
              SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    Text(author, style: TextStyle(fontSize: 14)),
                    Text(price, style: TextStyle(fontSize: 16, color: Colors.green)),
                  ],
                ),
              ),
              ElevatedButton(
                onPressed: () {
                  // Add the book to the cart
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('$title added to cart')),
                  );
                },
                child: Text('Add to Cart'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class BookDetailScreen extends StatelessWidget {
  final String imageUrl;

  const BookDetailScreen({required this.imageUrl});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Book Detail')),
      body: Center(
        child: Hero(
          tag: imageUrl,
          child: Image.asset(
            imageUrl,
            width: double.infinity,
            height: 300,
            fit: BoxFit.cover,
          ),
        ),
      ),
    );
  }
}