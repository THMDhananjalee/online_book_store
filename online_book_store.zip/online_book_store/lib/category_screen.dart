import 'package:flutter/material.dart';

class CategoryScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Categories')),
      body: ListView(
        children: [
          AnimatedCategoryTile(title: 'Fiction'),
          AnimatedCategoryTile(title: 'Non-Fiction'),
          AnimatedCategoryTile(title: 'Science Fiction'),
          AnimatedCategoryTile(title: 'Mystery'),
          AnimatedCategoryTile(title: 'Romance'),
        ],
      ),
    );
  }
}

class AnimatedCategoryTile extends StatefulWidget {
  final String title;

  const AnimatedCategoryTile({required this.title});

  @override
  _AnimatedCategoryTileState createState() => _AnimatedCategoryTileState();
}

class _AnimatedCategoryTileState extends State<AnimatedCategoryTile>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: Duration(milliseconds: 300),
      vsync: this,
    );
    _animation = Tween<double>(begin: 1.0, end: 0.95).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _onTap() {
    _controller.forward().then((_) {
      _controller.reverse();
      // Navigate to the selected category screen or perform an action
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${widget.title} selected')),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _onTap,
      child: ScaleTransition(
        scale: _animation,
        child: Card(
          margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: ListTile(
            title: Text(widget.title),
            trailing: Icon(Icons.arrow_forward_ios),
          ),
        ),
      ),
    );
  }
}